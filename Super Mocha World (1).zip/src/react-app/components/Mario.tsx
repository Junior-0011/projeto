import { useRef, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { Group, Vector3 } from 'three';
import { useKeyboard } from '@/react-app/hooks/useKeyboard';

interface MarioProps {
  position: [number, number, number];
  onPositionChange: (position: Vector3) => void;
}

export default function Mario({ position, onPositionChange }: MarioProps) {
  const groupRef = useRef<Group>(null);
  const keys = useKeyboard();
  
  const velocity = useRef({ x: 0, y: 0, z: 0 });
  const isGrounded = useRef(true);
  const currentPosition = useRef(new Vector3(...position));

  useEffect(() => {
    currentPosition.current.set(...position);
  }, [position]);

  useFrame((_, delta) => {
    if (!groupRef.current) return;

    const speed = 8;
    const jumpForce = 15;
    const gravity = -30;
    const friction = 0.85;

    // Horizontal movement
    if (keys.ArrowLeft || keys.KeyA) {
      velocity.current.x = Math.max(velocity.current.x - speed * delta, -speed);
      groupRef.current.rotation.y = Math.PI; // Face left
    } else if (keys.ArrowRight || keys.KeyD) {
      velocity.current.x = Math.min(velocity.current.x + speed * delta, speed);
      groupRef.current.rotation.y = 0; // Face right
    } else {
      velocity.current.x *= friction;
    }

    // Jumping
    if ((keys.Space || keys.ArrowUp || keys.KeyW) && isGrounded.current) {
      velocity.current.y = jumpForce;
      isGrounded.current = false;
    }

    // Apply gravity
    velocity.current.y += gravity * delta;

    // Update position
    currentPosition.current.x += velocity.current.x * delta;
    currentPosition.current.y += velocity.current.y * delta;

    // Ground collision (y = 0)
    if (currentPosition.current.y <= 1) {
      currentPosition.current.y = 1;
      velocity.current.y = 0;
      isGrounded.current = true;
    }

    // Update visual position
    groupRef.current.position.copy(currentPosition.current);
    onPositionChange(currentPosition.current);
  });

  return (
    <group ref={groupRef} position={position}>
      {/* Mario body - simple colored boxes for now */}
      {/* Head */}
      <mesh position={[0, 0.8, 0]}>
        <boxGeometry args={[0.8, 0.8, 0.8]} />
        <meshStandardMaterial color="#FFDBAC" />
      </mesh>
      
      {/* Hat */}
      <mesh position={[0, 1.2, 0]}>
        <boxGeometry args={[0.9, 0.4, 0.9]} />
        <meshStandardMaterial color="#FF0000" />
      </mesh>
      
      {/* Body */}
      <mesh position={[0, 0, 0]}>
        <boxGeometry args={[0.9, 1, 0.6]} />
        <meshStandardMaterial color="#0066FF" />
      </mesh>
      
      {/* Overalls */}
      <mesh position={[0, 0.1, 0.31]}>
        <boxGeometry args={[0.8, 0.8, 0.1]} />
        <meshStandardMaterial color="#FF0000" />
      </mesh>
      
      {/* Arms */}
      <mesh position={[-0.6, 0.2, 0]}>
        <boxGeometry args={[0.4, 0.8, 0.4]} />
        <meshStandardMaterial color="#FFDBAC" />
      </mesh>
      <mesh position={[0.6, 0.2, 0]}>
        <boxGeometry args={[0.4, 0.8, 0.4]} />
        <meshStandardMaterial color="#FFDBAC" />
      </mesh>
      
      {/* Legs */}
      <mesh position={[-0.3, -0.8, 0]}>
        <boxGeometry args={[0.4, 0.8, 0.4]} />
        <meshStandardMaterial color="#0066FF" />
      </mesh>
      <mesh position={[0.3, -0.8, 0]}>
        <boxGeometry args={[0.4, 0.8, 0.4]} />
        <meshStandardMaterial color="#0066FF" />
      </mesh>
      
      {/* Shoes */}
      <mesh position={[-0.3, -1.3, 0.2]}>
        <boxGeometry args={[0.5, 0.3, 0.8]} />
        <meshStandardMaterial color="#8B4513" />
      </mesh>
      <mesh position={[0.3, -1.3, 0.2]}>
        <boxGeometry args={[0.5, 0.3, 0.8]} />
        <meshStandardMaterial color="#8B4513" />
      </mesh>
    </group>
  );
}
