interface PlatformProps {
  position: [number, number, number];
  size: [number, number, number];
  color?: string;
}

export default function Platform({ position, size, color = "#8B4513" }: PlatformProps) {
  return (
    <mesh position={position}>
      <boxGeometry args={size} />
      <meshStandardMaterial color={color} />
    </mesh>
  );
}
