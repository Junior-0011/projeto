import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Mesh } from 'three';

interface CoinProps {
  position: [number, number, number];
  collected?: boolean;
  onCollect?: () => void;
}

export default function Coin({ position, collected = false, onCollect }: CoinProps) {
  const meshRef = useRef<Mesh>(null);

  useFrame((state) => {
    if (meshRef.current && !collected) {
      meshRef.current.rotation.y = state.clock.getElapsedTime() * 2;
      meshRef.current.position.y = position[1] + Math.sin(state.clock.getElapsedTime() * 3) * 0.1;
    }
  });

  if (collected) return null;

  return (
    <mesh ref={meshRef} position={position} onClick={onCollect}>
      <cylinderGeometry args={[0.3, 0.3, 0.1, 8]} />
      <meshStandardMaterial color="#FFD700" />
    </mesh>
  );
}
