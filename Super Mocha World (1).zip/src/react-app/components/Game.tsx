import { useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Environment } from '@react-three/drei';
import { Vector3 } from 'three';
import Mario from './Mario';
import Platform from './Platform';
import Coin from './Coin';

export default function Game() {
  const [marioPosition, setMarioPosition] = useState<Vector3>(new Vector3(0, 1, 0));
  const [coins, setCoins] = useState([
    { id: 1, position: [5, 3, 0] as [number, number, number], collected: false },
    { id: 2, position: [10, 5, 0] as [number, number, number], collected: false },
    { id: 3, position: [15, 2, 0] as [number, number, number], collected: false },
    { id: 4, position: [-5, 4, 0] as [number, number, number], collected: false },
  ]);
  const [score, setScore] = useState(0);

  const collectCoin = (coinId: number) => {
    setCoins(prev => prev.map(coin => 
      coin.id === coinId ? { ...coin, collected: true } : coin
    ));
    setScore(prev => prev + 100);
  };

  return (
    <div className="w-full h-screen relative bg-gradient-to-b from-blue-400 to-blue-600">
      {/* UI Overlay */}
      <div className="absolute top-4 left-4 z-10 text-white font-bold text-xl">
        <div>Score: {score}</div>
        <div className="text-sm mt-2">
          Use WASD or Arrow Keys to move, Space to jump
        </div>
      </div>

      {/* 3D Game Canvas */}
      <Canvas
        camera={{ 
          position: [0, 5, 15], 
          fov: 60,
          near: 0.1,
          far: 1000 
        }}
        shadows
      >
        <Environment preset="sunset" />
        
        {/* Lighting */}
        <ambientLight intensity={0.4} />
        <directionalLight 
          position={[10, 10, 10]} 
          intensity={1}
          castShadow
          shadow-mapSize={[2048, 2048]}
        />

        {/* Mario */}
        <Mario 
          position={[marioPosition.x, marioPosition.y, marioPosition.z]}
          onPositionChange={setMarioPosition}
        />

        {/* Platforms */}
        <Platform position={[0, -0.5, 0]} size={[20, 1, 2]} color="#228B22" />
        <Platform position={[8, 2, 0]} size={[4, 1, 2]} color="#8B4513" />
        <Platform position={[15, 1, 0]} size={[6, 1, 2]} color="#8B4513" />
        <Platform position={[-8, 3, 0]} size={[4, 1, 2]} color="#8B4513" />
        <Platform position={[3, 6, 0]} size={[3, 1, 2]} color="#8B4513" />
        <Platform position={[-15, 1, 0]} size={[4, 1, 2]} color="#8B4513" />

        {/* Coins */}
        {coins.map(coin => (
          <Coin
            key={coin.id}
            position={coin.position}
            collected={coin.collected}
            onCollect={() => collectCoin(coin.id)}
          />
        ))}

        {/* Camera Controls */}
        <OrbitControls 
          target={[marioPosition.x, marioPosition.y, marioPosition.z]}
          enablePan={false}
          enableZoom={true}
          enableRotate={true}
          maxPolarAngle={Math.PI / 2}
          minDistance={5}
          maxDistance={25}
        />
      </Canvas>
    </div>
  );
}
