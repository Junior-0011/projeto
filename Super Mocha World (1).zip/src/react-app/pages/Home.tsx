import Game from '@/react-app/components/Game';

export default function Home() {
  return <Game />;
}
